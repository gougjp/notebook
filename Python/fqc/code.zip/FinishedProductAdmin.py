import os
import re
import sys
import time
import datetime
from PyQt5 import QtCore, QtGui
from PyQt5.QtWidgets import QApplication, QDialog, QMessageBox, QFileDialog, QMainWindow, QLineEdit
from FinishedProductAdminUi import *
# from LoginUi import *
from CommonStyle import *

def base_path():
    if getattr(sys, 'frozen', None):
        basedir = sys._MEIPASS
    else:
        basedir = os.path.dirname(__file__)

    return basedir

"""
class LogInDB(QDialog, Ui_Dialog):
    def __init__(self, parent=None):
        super(LogInDB, self).__init__(parent)
        self.setupUi(self)
        self.username = None
        self.password = None

        self.lineEdit.editingFinished.connect(self.get_username)
        self.lineEdit_2.setEchoMode(QLineEdit.Password)
        self.lineEdit_2.editingFinished.connect(self.get_password)

        self.pushButton.clicked.connect(self.logindb)
        self.pushButton_2.clicked.connect(self.cancel)

    def get_username(self):
        self.username = self.lineEdit.text()

    def get_password(self):
        self.password = self.lineEdit_2.text()

    def logindb(self):
        # 检查用户名和密码
        if self.username == None or self.password == None:
            QMessageBox.information(self, '登录', '请输入用户名和密码')
            return

        db = DataBase()
        # 登陆数据库
        try:
            db.connect(self.username, self.password)
        except Exception as ex:
            print(ex)
            QMessageBox.information(self, '登录', '登录数据库失败, 请确认用户名和密码是否正确')
            return

        db.close()
        self.accept()
        
    def cancel(self):
        sys.exit()
"""

class FQCMainUI(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(FQCMainUI, self).__init__(parent)
        self.setupUi(self)
        
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    the_window = FQCMainUI()

    qssStyle = CommonStyle.readQss(os.path.join(base_path(), 'Qss', 'style.qss'))
    the_window.setStyleSheet(qssStyle)

    the_window.show()
    sys.exit(app.exec_())

    # app = QApplication(sys.argv)
    # dialog = LogInDB()
    # if dialog.exec_() == QDialog.Accepted:
        # the_window = FQCMainUI()
        # the_window.show()
        # sys.exit(app.exec_())
