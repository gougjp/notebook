from django.apps import AppConfig


class FqcConfig(AppConfig):
    name = 'fqc'
