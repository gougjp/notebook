from django.shortcuts import render, render_to_response
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
from django.http import HttpResponse, HttpResponseRedirect
from fqc.models import AutodtSpecTco, AutodtLogin
import json

def index(request):
    return render_to_response("home.html", {'username':request.user.username})

@csrf_exempt
def login(request):
    if request.method == 'GET':
        return render_to_response("login.html", {})

    user = request.POST.get('username', '')
    passwd = request.POST.get('password', '')

    if user == '' or passwd == '':
        return render(request, 'login.html')
        
    result = AutodtLogin.objects.filter(username=user)
    if len(result) == 0:
        return HttpResponse(json.dumps({'code': 401, 'message': 'User does not exist', 'data': None}, ensure_ascii=False))
    elif result[0].password != passwd:
        return HttpResponse(json.dumps({'code': 401, 'message': 'The password is incorrect', 'data': None}, ensure_ascii=False))
    else:
        items = AutodtSpecTco.objects.all()
        return render_to_response("gettco.html", {'list':items})

def gettco(request):
    items = AutodtSpecTco.objects.all()
    return render_to_response("gettco.html", {'list':items})

@csrf_exempt
def inserttco(request):
    if request.method == 'GET':
        return render_to_response("inserttco.html", {})
    else:
        tcocode = request.POST.get('tcocode', '')
        effectivedate = request.POST.get('effectivedate', '')
        effectiveflag = request.POST.get('effectiveflag', '')
        username = request.POST.get('username', '')
        partnumber = request.POST.get('partnumber', '')
        modifydate = request.POST.get('modifydate', '')
        bom = request.POST.get('bom', '')
        scgd = request.POST.get('scgd', '')
        deletedate = request.POST.get('deletedate', '')

        idlist = AutodtSpecTco.objects.all().values('id')
        expid = max([idv['id'] for idv in idlist]) + 1

        dic = {'id':expid, 'tcocode':tcocode, 'effectivedate':effectivedate, 'effectiveflag':effectiveflag, 'username':username, 'partnumber':partnumber, 'modifydate':modifydate, 'bom':bom, 'scgd':scgd, 'deletedate':deletedate}
        AutodtSpecTco.objects.create(**dic)

        #return HttpResponse(json.dumps({'code': 201, 'message': 'success', 'data': None}, ensure_ascii=False))
        items = AutodtSpecTco.objects.all()
        return render_to_response("gettco.html", {'list':items})

