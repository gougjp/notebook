$(document).ready(function() {
    $('#table1').DataTable( {
        autoWidth: true,
        bFilter: false,
        bLengthChange: false,
        "lengthMenu": [10, 20, 50, 100],
        "displayLength": 20,
        "language": {
            "decimal": ",",
            "thousands": "."
        }
    });
});
