from django.urls import path

from . import views

urlpatterns = [
    #path('', views.index, name='index'),
    path('gettco', views.gettco, name='gettco'),
    path('inserttco', views.inserttco, name='inserttco'),
    path('login', views.login, name='login'),
    path('', views.index, name='home'),
]
