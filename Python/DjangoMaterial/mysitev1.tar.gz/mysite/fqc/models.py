# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models


class AutodtLogin(models.Model):
    id = models.BigIntegerField(primary_key=True)
    username = models.TextField(blank=True, null=True)  # This field type is a guess.
    password = models.TextField(blank=True, null=True)  # This field type is a guess.
    power = models.TextField(blank=True, null=True)  # This field type is a guess.
    modifydate = models.TextField(blank=True, null=True)  # This field type is a guess.

    class Meta:
        managed = False
        db_table = 'autodt_login'


class AutodtSpecTco(models.Model):
    id = models.BigIntegerField(primary_key=True)
    tcocode = models.TextField(blank=True, null=True)  # This field type is a guess.
    effectivedate = models.TextField(blank=True, null=True)  # This field type is a guess.
    effectiveflag = models.BigIntegerField(blank=True, null=True)
    username = models.TextField(blank=True, null=True)  # This field type is a guess.
    partnumber = models.TextField(blank=True, null=True)  # This field type is a guess.
    modifydate = models.TextField(blank=True, null=True)  # This field type is a guess.
    bom = models.TextField(blank=True, null=True)  # This field type is a guess.
    scgd = models.TextField(blank=True, null=True)  # This field type is a guess.
    deletedate = models.TextField(blank=True, null=True)  # This field type is a guess.

    class Meta:
        managed = False
        db_table = 'autodt_spec_tco'
