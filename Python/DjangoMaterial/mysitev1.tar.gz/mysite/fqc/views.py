from django.shortcuts import render, render_to_response

# Create your views here.
from django.http import HttpResponse
from fqc.models import AutodtSpecTco, AutodtLogin

def index(request):
    items = AutodtSpecTco.objects.all()
    return render_to_response("table.html", {'list':items})

